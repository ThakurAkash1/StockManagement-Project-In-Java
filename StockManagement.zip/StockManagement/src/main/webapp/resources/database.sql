create database stockmanagement;
use stockmanagement;

create table product (product_code varchar(255) primary key,
                       product_name varchar(255),
					   product_price varchar(255),
                       product_quantity varchar(255),
                       date_of_manufacture date,
					   date_of_expiry date);
insert into product values('1001','kitkat',25, 2,'5.4.2022','20.10.2022');
insert into product values('1002','LOREALPARIS',250, 1,'5.04.2021','20.11.2022');
insert into product values('1005','Pastry',552, 12,'03.04.2022','02.03.2025');
SELECT * FROM PRODUCT;

create table register(username varchar(255),password varchar(255),firstname varchar(255),lastname varchar(255),address varchar(255),phoneno varchar(255),emailid varchar(255));
insert into register values("Akash",'123','AKASH',"THAKUR","kalaburagi","9019596952","akashrthakur786@gmail.com");
SELECT * FROM REGISTER;


create table customer(customerid int primary key not null auto_increment,customername varchar(255),phoneno varchar(255),address varchar(255),product_name varchar(255),product_quantity varchar(255));
insert into customer (customername, phoneno, address, product_name, product_quantity) values ("Akash","561121","GLB","LUX","3");
SELECT * FROM CUSTOMER;