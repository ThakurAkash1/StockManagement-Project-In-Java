package StockManagement.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import StockManagement.Dao.StockDao;



/**
 * Servlet implementation class ValidateUserLogin
 */
@WebServlet("/UserLogin")
public class ValidateUserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private StockDao stockdao=new StockDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateUserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username =request.getParameter("username");
		String password =request.getParameter("password");
		
		try {
			if(stockdao.LoginUser(username, password)) {
			    RequestDispatcher rd=request.getRequestDispatcher("/Display.jsp");  
			    rd.forward(request,response);  
			} else{  
				RequestDispatcher rd=request.getRequestDispatcher("/Display1.jsp");  
			    rd.forward(request,response);   
			//response.getWriter().print();
			
			//doGet(request, response);
}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
	}

		//doGet(request, response);
	}

}
