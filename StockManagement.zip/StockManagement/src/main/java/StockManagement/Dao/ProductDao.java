package StockManagement.Dao;

import java.sql.Connection;

import StockManagement.Model.Customer;
import StockManagement.Model.Register;
import StockManagement.Utilities.DBConnectionUtility;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;





@SuppressWarnings("unused")
public class ProductDao {
	
	private static final String INSERT_REGISTER_DETAILS = "insert into stockmanagement.register"															
															+ "(username,"
															+ "password,"
															+ "firstname,"
															+ "lastname,"
															+ "address,"
															+ "phoneno,"
															+ "emailid)"
															+ " VALUES (?,?,?,?,?,?,?); ";
	private static final String INSERT_CUSTOMER_DETAILS ="insert into stockmanagement.customer("
																					+ "customername, "
																					+ "phoneno, "
																					+ "address, "
																					+ "product_name, "
																					+ "product_quantity)"
																					+ " values (?,?,?,?,?); ";
	
	
	private static ProductDao instance;
	private Connection connection = null;
	private PreparedStatement preparedStatement = null;
	
	public static ProductDao getInstance() {
		if(instance == null)
			instance = new ProductDao();
		return instance;
	}
		
public String registration(Register register) throws ClassNotFoundException{
		
		String result = "Data Entered Successfully !!!"; 
		
		try {
			connection = DBConnectionUtility.getDBConnection();
			preparedStatement = connection.prepareStatement(INSERT_REGISTER_DETAILS);
			preparedStatement.setString(1, register.getUserName() );
			preparedStatement.setString(2, register.getPassword());
			preparedStatement.setString(3,  register.getFirstName());
			preparedStatement.setString(4,  register.getLastName());
			preparedStatement.setString(5, register.getAddress());
			preparedStatement.setString(6, register.getPhoneno());
			preparedStatement.setString(7, register.getEmailid());
			
			preparedStatement.executeUpdate();
			}
		catch (SQLException ex) {
			result = "Data is not stored "+ex.getLocalizedMessage();
			ex.printStackTrace();
		}
		return result;
	}

public String register(Customer customer) throws ClassNotFoundException {

	String result = "products added Successfully !!!";

	try {
		connection = DBConnectionUtility.getDBConnection();
		preparedStatement = connection.prepareStatement(INSERT_CUSTOMER_DETAILS);
		preparedStatement.setString(1, customer.getCustomer_Name());
		preparedStatement.setString(2, customer.getPhoneno());
		preparedStatement.setString(3, customer.getAddress());
		preparedStatement.setString(4, customer.getProduct_Name());
		preparedStatement.setString(5, customer.getProduct_Quantity());
		

		preparedStatement.executeUpdate();
	} catch (SQLException ex) {
		result = "Data is not stored " + ex.getLocalizedMessage();
		ex.printStackTrace();
	}
	return result;
}


}