package StockManagement.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import StockManagement.Dao.ProductDao;
import StockManagement.Model.Register;

/**
 * Servlet implementation class register
 */
@WebServlet("/registername")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductDao productDao=new ProductDao();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String UserName = request.getParameter("username");
		String Password = request.getParameter("password");
		String FirstName = request.getParameter("firstname");
		String LastName = request.getParameter("lastname");
		String Address = request.getParameter("address");
		String Phoneno = request.getParameter("phone");
		String Emailid = request.getParameter("mailid");
		
		Register R=new Register();
		R.setUserName(UserName);
		R.setPassword(Password);
		R.setFirstName(FirstName);
		R.setLastName(LastName);
		R.setAddress(Address);
		R.setPhoneno(Phoneno);
		R.setEmailid(Emailid);
		
		String r="";
		try {
			r = productDao.registration(R);
			System.out.println(r);
			
		} catch (ClassNotFoundException e) {
			System.out.println(r+" "+e);
			e.printStackTrace();
		}
		response.getWriter().print(r);
	
		
	}

}