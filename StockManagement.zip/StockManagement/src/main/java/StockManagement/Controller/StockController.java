package StockManagement.Controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import StockManagement.Dao.StockDao;
import StockManagement.Model.StockModel;





/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/register")
public class StockController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StockDao stockDao = new StockDao();
		





	public StockController() {
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//RequestDispatcher dispatcher = request.getRequestDispatcher("/studentRegister.jsp");
		//dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Product_Code = request.getParameter("Product_Code");
		String Product_Name = request.getParameter("Product_Name");
		String Product_Price = request.getParameter("Product_Price");
		String Product_Quantity = request.getParameter("Product_Quantity");
		String Date_Of_Manufacture = request.getParameter("Date_Of_Manufacture");
		String Date_Of_Expiry = request.getParameter("Date_Of_Expiry");
		
		StockModel stock_Model = new StockModel();
		
		stock_Model.setProduct_Code(Product_Code);
		stock_Model.setProduct_Name(Product_Name);
		stock_Model.setProduct_Price(Product_Price);
		stock_Model.setProduct_Quantity(Product_Quantity);
		stock_Model.setDate_Of_Manufacture(Date_Of_Manufacture);
		stock_Model.setDate_Of_Expiry(Date_Of_Expiry);
		
		
		String r="";
		try {
			r = stockDao.registerStockModel(stock_Model);
			System.out.println(r);
			
		} catch (ClassNotFoundException e) {
			System.out.println(r+" "+e);
			e.printStackTrace();
		}
		response.getWriter().print(r);
		 
		//RequestDispatcher dispatcher = request.getRequestDispatcher("/retrive.jsp");
		//dispatcher.forward(request, response);
	}

}