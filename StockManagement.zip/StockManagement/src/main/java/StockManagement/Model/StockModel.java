package StockManagement.Model;

public class StockModel {
	
	private String Product_Code;	
	private String Product_Name;	
	private String Product_Price;	
	private String Product_Quantity;
	private String Date_Of_Manufacture;
	private String Date_Of_Expiry;
	
	public StockModel() {
		super ();
	}

	

	public StockModel(String product_Code, String product_Name, String product_Price, String product_Quantity,
			String date_Of_Manufacture, String date_Of_Expiry) {
		super();
		Product_Code = product_Code;
		Product_Name = product_Name;
		Product_Price = product_Price;
		Product_Quantity = product_Quantity;
		Date_Of_Manufacture = date_Of_Manufacture;
		Date_Of_Expiry = date_Of_Expiry;
	}



	public String getProduct_Code() {
		return Product_Code;
	}



	public void setProduct_Code(String product_Code) {
		Product_Code = product_Code;
	}



	public String getProduct_Name() {
		return Product_Name;
	}



	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}



	public String getProduct_Price() {
		return Product_Price;
	}



	public void setProduct_Price(String product_Price) {
		Product_Price = product_Price;
	}



	public String getProduct_Quantity() {
		return Product_Quantity;
	}



	public void setProduct_Quantity(String product_Quantity) {
		Product_Quantity = product_Quantity;
	}



	public String getDate_Of_Manufacture() {
		return Date_Of_Manufacture;
	}



	public void setDate_Of_Manufacture(String date_Of_Manufacture) {
		Date_Of_Manufacture = date_Of_Manufacture;
	}



	public String getDate_Of_Expiry() {
		return Date_Of_Expiry;
	}



	public void setDate_Of_Expiry(String date_Of_Expiry) {
		Date_Of_Expiry = date_Of_Expiry;
	}



	
	
	
}