package StockManagement.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import StockManagement.Dao.ProductDao;
import StockManagement.Model.Customer;


/**
 * Servlet implementation class Register
 */
@WebServlet("/r3")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private ProductDao productdao=new ProductDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String customername = request.getParameter("customername");
		String phoneno = request.getParameter("phoneno");
		String address = request.getParameter("address");
		String productname = request.getParameter("product_name");
		String productquantity = request.getParameter("product_quantity");
		

		Customer customer=new Customer();
		customer.setCustomer_Name(customername);
		customer.setPhoneno(phoneno);
		customer.setAddress(address);
		customer.setProduct_Name(productname);
		customer.setProduct_Quantity(productquantity);
		
		String result = "";
		try {
			result = productdao.register(customer);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/Generate.jsp");
			dispatcher.forward(request, response);

		} catch (ClassNotFoundException e) {
			System.out.println(result + " " + e);
			e.printStackTrace();
		}
		response.getWriter().print(result);

	}
}