package StockManagement.Model;

public class Register {
	private String UserName;	
	private String Password;	
	private String FirstName;	
	private String LastName;
	private String Address;
	private String Phoneno;
	private String Emailid;
	public Register() {
		super();
		
	}
	public Register(String userName, String password, String firstName, String lastName, String address, String phoneno,
			String emailid) {
		super();
		UserName = userName;
		Password = password;
		FirstName = firstName;
		LastName = lastName;
		Address = address;
		Phoneno = phoneno;
		Emailid = emailid;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhoneno() {
		return Phoneno;
	}
	public void setPhoneno(String phoneno) {
		Phoneno = phoneno;
	}
	public String getEmailid() {
		return Emailid;
	}
	public void setEmailid(String emailid) {
		Emailid = emailid;
	}
}