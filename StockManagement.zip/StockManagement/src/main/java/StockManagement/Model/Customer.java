package StockManagement.Model;

public class Customer {
	
	private String Customer_Name;
	private String Phoneno;
	private String Address;
	private String Product_Name;
	private String Product_Quantity;

	public Customer() {
		super();
	}

	public Customer(String customer_Name, String phoneno, String address, String product_Name,
			String product_Quantity) {
		super();
		Customer_Name = customer_Name;
		Phoneno = phoneno;
		Address = address;
		Product_Name = product_Name;
		Product_Quantity = product_Quantity;
	}

	public String getCustomer_Name() {
		return Customer_Name;
	}

	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}

	public String getPhoneno() {
		return Phoneno;
	}

	public void setPhoneno(String phoneno) {
		Phoneno = phoneno;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public String getProduct_Quantity() {
		return Product_Quantity;
	}

	public void setProduct_Quantity(String product_Quantity) {
		Product_Quantity = product_Quantity;
	}
	
	
}