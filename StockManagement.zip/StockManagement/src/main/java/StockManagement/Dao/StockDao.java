package StockManagement.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import StockManagement.Model.StockModel;
import StockManagement.Utilities.DBConnectionUtility;



public class StockDao {
	
	private static final String VAL_DETAILS = "select username,password from stockmanagement.register  WHERE username=? and password=?;";	
	private static final String INSERT_PRODUCT_DETAILS = "insert into stockmanagement.product"															
															+ "(Product_Code,"
															+ "Product_Name,"
															+ "Product_Price,"
															+ "Product_Quantity,"
															+ "Date_Of_Manufacture,"
															+ "Date_Of_Expiry)"
															+ " VALUES (?,?,?,?,?,?); ";
	
	
	private static StockDao instance;
	private Connection connection = null;
	private PreparedStatement preparedStatement = null;
	
	public static StockDao getInstance() {
		if(instance == null)
			instance = new StockDao();
		return instance;
	}
	

	
	
public String registerStockModel(StockModel stock_Model) throws ClassNotFoundException{
		
		String result = "Data Entered Successfully !!!"; 
		
		try {
			connection = DBConnectionUtility.getDBConnection();
			preparedStatement = connection.prepareStatement(INSERT_PRODUCT_DETAILS);
			preparedStatement.setString(1,  stock_Model.getProduct_Code());
			preparedStatement.setString(2, stock_Model.getProduct_Name());
			preparedStatement.setString(3,  stock_Model.getProduct_Price());
			preparedStatement.setString(4,  stock_Model.getProduct_Quantity());
			preparedStatement.setString(5, stock_Model.getDate_Of_Manufacture());
			preparedStatement.setString(6, stock_Model.getDate_Of_Expiry());
			preparedStatement.executeUpdate();
			}
		catch (SQLException ex) {
			result = "Data is not stored "+ex.getLocalizedMessage();
			ex.printStackTrace();
		}
		return result;
		
	}
public  boolean LoginUser(String username, String password) throws ClassNotFoundException{
	
	@SuppressWarnings("unused")
	String result = ""; 
	boolean res=false;
	
	try {
		connection = DBConnectionUtility.getDBConnection();
		preparedStatement = connection.prepareStatement(VAL_DETAILS);
		preparedStatement.setString(1, username);
		preparedStatement.setString(2, password);
		
		ResultSet rs=preparedStatement.executeQuery();
		res=rs.next();
}catch (Exception e) {
	System.out.println(e);
	
	
}
	return res;

}

}

